Command on mac for uploading to Chrome Web Store
```zip -r yt-fact-checker-x-button.zip *```